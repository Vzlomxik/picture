#! /bin/sh
npm i --only=prod --no-audit --no-progress --loglevel=error
exit 0
