#! /bin/sh
node index
exit 0
