module.exports = {
  initPixelCanvas: null,
}
